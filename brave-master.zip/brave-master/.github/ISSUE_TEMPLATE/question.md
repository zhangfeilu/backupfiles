---
name: Question
about: This issue tracker is not for questions. If you want to ask how to do something, or to understand why something isn't working the way you expect it to, please use https://gitter.im/openzipkin/zipkin

---

This issue tracker is not for questions. If you want to ask how to do something, or to understand why something isn't working the way you expect it to, please use [Gitter](https://gitter.im/openzipkin/zipkin), [Stack Overflow](https://stackoverflow.com/questions/tagged/zipkin) or [email zipkin-user@googlegroups.com](https://groups.google.com/forum/#!forum/zipkin-user)
