# brave-tests

This module contains test base classes used to ensure extensions work
portably.
