# brave-instrumentation-http-tests

This module contains test base classes used to ensure instrumentation
work portably.
