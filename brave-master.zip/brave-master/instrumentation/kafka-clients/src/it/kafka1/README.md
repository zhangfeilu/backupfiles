# kafka1
This tests that KafkaPropagation can be used with kafka-client v<2
