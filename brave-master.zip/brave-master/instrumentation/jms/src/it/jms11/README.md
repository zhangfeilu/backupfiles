# Jms 1.1
This tests that JmsTracing does not rely on JMS 2.0 apis
