# grpc12
This tests that GrpcTracing does not require Grpc >1.2
