package me.anduo.rpc.server.modules.sample;

public interface HelloService {

	String hello(String name);
}
